package com.sqliid.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Random;

public class Util {
	
	public static String generateDataID() {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMhhmmsss");
		return sdf.format(new Timestamp(System.currentTimeMillis()));
	}
	
	public static String generatePassword() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 7) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

	}

}
