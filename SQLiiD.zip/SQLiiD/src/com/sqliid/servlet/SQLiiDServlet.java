package com.sqliid.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aklc.core.SQLiID;
import com.sqliid.dao.ClientDAO;
import com.sqliid.dao.ResultDAO;
import com.sqliid.dao.ServiceUsageDAO;
import com.sqliid.daoimpl.ClientDAOImpl;
import com.sqliid.daoimpl.ResultDAOImpl;
import com.sqliid.daoimpl.ServiceUsageDAOImpl;
import com.sqliid.pojo.Result;
import com.sqliid.pojo.ServiceUsage;

public class SQLiiDServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		SQLiID sqlid = new SQLiID();
		ServiceUsageDAO serviceusagedao = new ServiceUsageDAOImpl();
		ResultDAO resultdao = new ResultDAOImpl();
		try {
			String query = req.getParameter("query");
			String clientid = req.getParameter("clientid");
			String passcode = req.getParameter("passcode");

			if (query == null || query.trim().length() == 0 || clientid == null || clientid.trim().length() == 0
					|| passcode == null || passcode.trim().length() == 0) {

				pw.print("Invalid Request");
			} else {

				ClientDAO clientdao = new ClientDAOImpl();
				String result = "";

				if (clientdao.isValidClient(clientid, passcode)) {

					if (sqlid.isGrammarCorrect(query.toUpperCase())) {
						if (sqlid.testAgainstWhiteList(query.toUpperCase())) {
							if (!sqlid.testAgainstBlackList(query.toUpperCase())) {
								result = "Safe";
							} else {
								result = "Unsafe: Black list test failed";
							}
						} else {
							result = "Unsafe: White list test failed";
						}
					} else {
						result = "Unsafe: Grammar check failed";
					}

					ServiceUsage serviceusage = new ServiceUsage();
					serviceusage.setClientid(clientid);
					serviceusage.setQuery(query);
					serviceusagedao.write(serviceusage);
					Result res = new Result();
					res.setClientid(clientid);
					res.setQuery(query);
					res.setResult(result);
					resultdao.write(res);
  
				} else {
					result = "Client Not Authorized";
				}
				pw.print(result);

			}
		} catch (Exception e) {
			e.printStackTrace();
			pw.println("Error:" + e.getMessage());
		}
		pw.close();
	}

}
