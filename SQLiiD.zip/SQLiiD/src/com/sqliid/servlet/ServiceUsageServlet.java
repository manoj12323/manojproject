package com.sqliid.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sqliid.dao.ServiceUsageDAO;
import com.sqliid.daoimpl.ServiceUsageDAOImpl;

public class ServiceUsageServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String type = req.getParameter("type");
			ServiceUsageDAO serviceusagedao = new ServiceUsageDAOImpl();

			if (type != null && type.equals("remove")) {
				serviceusagedao.remove(req.getParameter("clientid"));
				resp.sendRedirect("serviceusage?msg=Removed the client: "+req.getParameter("clientid"));
			} else {
				req.setAttribute("usage", serviceusagedao.read());
				req.getRequestDispatcher("service_usage.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resp.sendRedirect("service_usage.jsp?msg=Something went wrong");
		}
	}

}
