package com.sqliid.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sqliid.dao.ClientDAO;
import com.sqliid.daoimpl.ClientDAOImpl;
import com.sqliid.mail.MailThread;
import com.sqliid.pojo.Client;
import com.sqliid.util.Util;

public class WebserviceServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String email = req.getParameter("email");
			String addr = req.getParameter("addr");
			String passcode = Util.generatePassword();
			String subject = "Your SQLiiD portal access";
			String body = "Hello, <br/> Your SQLiiD Portal access has been granted and here are the details of it.<br/><br/>";
			body += "Service End Point: <b>" + "http://localhost:8080/SQLiiD/sqlid" + "</b><br/>";
			body += "Parameters required: <b>clientid</b>, <b>passcode</b>, and <b>query</b><br/><br/>";
			body += "Client ID: <b>" + email + "</b><br/>";
			body += "Passcode: <b>" + passcode + "</b><br/>";

			ClientDAO clientdao = new ClientDAOImpl();
			Client client  =new Client();
			client.setClientid(email);
			client.setPasscode(passcode);
			
			clientdao.write(client  );
			
			List<String> rcv = new ArrayList<>();
			rcv.add(email);
			MailThread mail = new MailThread(body, subject, rcv);
			resp.sendRedirect("webservice.jsp?msg=Invite Successfully sent to the Client");

		} catch (Exception e) {
			e.printStackTrace();
			resp.sendRedirect("webservice.jsp?msg=Something went wrong");
		}
	}

}
