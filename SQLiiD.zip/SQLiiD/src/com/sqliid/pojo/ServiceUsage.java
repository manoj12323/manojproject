package com.sqliid.pojo;

import java.sql.Timestamp;

public class ServiceUsage {
	
	String clientid;
	String query;
	Timestamp entry_time;
	public String getClientid() {
		return clientid;
	}
	public void setClientid(String clientid) {
		this.clientid = clientid;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public Timestamp getEntry_time() {
		return entry_time;
	}
	public void setEntry_time(Timestamp entry_time) {
		this.entry_time = entry_time;
	}
	
	
	

}
