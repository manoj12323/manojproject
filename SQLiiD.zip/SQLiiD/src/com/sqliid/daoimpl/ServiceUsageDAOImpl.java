package com.sqliid.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sqliid.dao.ServiceUsageDAO;
import com.sqliid.pojo.ServiceUsage;
import com.sqliid.util.MySQLUtility;

public class ServiceUsageDAOImpl implements ServiceUsageDAO {

	public void write(ServiceUsage s) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			PreparedStatement ps = con.prepareStatement("insert into service_usage values (?,?,?)");
			ps.setString(1, s.getClientid());
			ps.setString(2, s.getQuery());
			ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
			ps.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

	public void remove(String clientid) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			con.createStatement().execute("delete from service_usage where clientid='"+clientid+"' ");
			con.createStatement().execute("delete from clien where clientid='"+clientid+"' ");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

	public Map<String, List<ServiceUsage>> read() throws Exception {
		Connection con = null;
		Map<String, List<ServiceUsage>> result = new HashMap<String, List<ServiceUsage>>();
		try {
			con = MySQLUtility.connect();
			ResultSet rs = con.createStatement().executeQuery("select * from service_usage");
			while (rs.next()) {
				List<ServiceUsage> list = new ArrayList<>();
				ServiceUsage s = new ServiceUsage();
				s.setClientid(rs.getString("clientid"));
				s.setQuery(rs.getString("query"));
				s.setEntry_time(rs.getTimestamp("entry_time"));
				
				if (result.containsKey(s.getClientid())) {					
					list.addAll(result.get(s.getClientid()));
				} 
				list.add(s);
				result.put(s.getClientid(), list);
				
			}
			ResultSet rs2 = con.createStatement().executeQuery("select * from client");
			while (rs2.next()) {
				String clientid = rs2.getString("clientid");
				if (!result.containsKey(clientid)) {
//					result.put(clientid, new ArrayList<>());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
		return result;
	}
}
