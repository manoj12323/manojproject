package com.sqliid.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sqliid.dao.ResultDAO;
import com.sqliid.dao.ServiceUsageDAO;
import com.sqliid.pojo.Result;
import com.sqliid.pojo.ServiceUsage;
import com.sqliid.util.MySQLUtility;

public class ResultDAOImpl implements ResultDAO {

	public void write(Result s) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			PreparedStatement ps = con.prepareStatement("insert into result values (?,?,?,?)");
			ps.setString(1, s.getClientid());
			ps.setString(2, s.getQuery());
			ps.setString(3, s.getResult());
			ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			ps.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

	public Map<String, List<Result>> read() throws Exception {
		Connection con = null;
		Map<String, List<Result>> result = new HashMap<String, List<Result>>();
		try {
			con = MySQLUtility.connect();
			ResultSet rs = con.createStatement().executeQuery("select * from result");
			while (rs.next()) {
				List<Result> list = new ArrayList<>();
				Result s = new Result();
				s.setClientid(rs.getString("clientid"));
				s.setQuery(rs.getString("query"));
				s.setResult(rs.getString("result"));
				s.setEntry_time(rs.getTimestamp("entry_time"));
				
				if (result.containsKey(s.getClientid())) {					
					list.addAll(result.get(s.getClientid()));
				} 
				list.add(s);
				result.put(s.getClientid(), list);
				
			}
			ResultSet rs2 = con.createStatement().executeQuery("select * from client");
			while (rs2.next()) {
				String clientid = rs2.getString("clientid");
				if (!result.containsKey(clientid)) {
//					result.put(clientid, new ArrayList<>());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
		return result;
	}
}
