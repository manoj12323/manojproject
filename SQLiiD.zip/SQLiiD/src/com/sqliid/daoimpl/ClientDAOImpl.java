package com.sqliid.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.sqliid.dao.ClientDAO;
import com.sqliid.pojo.Client;
import com.sqliid.util.MySQLUtility;

public class ClientDAOImpl implements ClientDAO {

	public void write(Client client) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			PreparedStatement ps = con.prepareStatement("insert into client values (?,?) ");
			ps.setString(1, client.getClientid());
			ps.setString(2, client.getPasscode());
			ps.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

	public void deleteClient(String email) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			con.createStatement().executeQuery("delete from client where clientid='" + email + "' ");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

	public boolean isValidClient(String clientid, String passcode) throws Exception {
		Connection con = null;
		try {
			con = MySQLUtility.connect();
			ResultSet rs = con.createStatement().executeQuery(
					"select count(*) from client where clientid='" + clientid + "' and passcode='" + passcode + "' ");
			rs.next();
			if (rs.getInt(1) > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			con.close();
		}
	}

}
