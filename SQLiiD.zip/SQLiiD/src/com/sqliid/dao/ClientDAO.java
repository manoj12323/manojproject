package com.sqliid.dao;

import com.sqliid.pojo.Client;

public interface ClientDAO {

	public void write(Client client) throws Exception;

	public void deleteClient(String email) throws Exception;

	public boolean isValidClient(String clientid, String passcode) throws Exception;
}
