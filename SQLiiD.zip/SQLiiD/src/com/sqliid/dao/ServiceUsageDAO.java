package com.sqliid.dao;

import java.util.List;
import java.util.Map;

import com.sqliid.pojo.ServiceUsage;

public interface ServiceUsageDAO {
	public void write(ServiceUsage s) throws Exception;

	public Map<String, List<ServiceUsage>> read() throws Exception;

	public void remove(String clientid) throws Exception;

}
