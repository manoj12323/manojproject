package com.sqliid.dao;

import java.util.List;
import java.util.Map;

import com.sqliid.pojo.Result;

public interface ResultDAO {


	public void write(Result s) throws Exception;

	public Map<String, List<Result>> read() throws Exception;


}
