import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SQLiID {

	// String white_list[] = {
	// "SELECT\\s((\\*)|(DISTINCT\\s[a-zA-Z,]+)|([\\sa-zA-Z,()]+))\\sFROM\\s([A-Z][a-z]+|[a-z]+)((\\sORDER\\sBY\\s([A-Z][a-z]+|[a-z]+)))?\\;$",
	// "SELECT\\s((\\*)|(DISTINCT\\s[a-zA-Z,]+)|([\\sa-zA-Z,]+))\\sFROM\\s([A-Z][a-z]+|[a-z]+)((\\sORDER\\sBY\\s([A-Z][a-z]+|[a-z]+)))?\\;$",
	// "SELECT\\s((\\*)|(DISTINCT\\s[a-zA-Z,]+)|([\\sa-zA-Z,]+))\\sFROM\\s([A-Z][a-z]+|[a-z]+)((\\sORDER\\sBY\\s([A-Z][a-z]+|[a-z]+)))?((\\sWHERE\\s[\\sa-zA-Z,\\*\\'\\=]+))?((\\;))?$",
	// "SELECT\\sCOUNT\\s\\*\\sFROM\\s([A-Z][a-z]+|[a-z]+)\\;$",
	// "SELECT\\s((\\*)|([\\sa-zA-Z,]+))\\sFROM\\s([A-Z][a-z]+|[a-z]+)((\\sWHERE\\s[\\sa-zA-Z,\\*\\'\\=]+))((\\;))?$",
	// "SELECT\\s([a-zA-Z]+)\\(([a-zA-Z]+)\\)\\sFROM\\s([A-Z][a-z]+|[a-z]+)\\;$",
	// "SELECT\\s((\\*)|([\\sa-zA-Z,()]+))\\sFROM\\s([A-Z][a-z]+|[a-z]+)\\sWHERE\\s.+?\\;$",
	// "UPDATE.+?SET\\s[a-z]+\\s?\\=[a-z'\\s]+((\\;$)|(\\sWHERE\\s.+?\\;$))",
	// "INSERT
	// INTO\\s([a-zA-Z\\(\\)\\,\\s]+)\\sVALUES([a-zA-Z\\(\\)\\,\\s\\'\\d]+)\\;$",
	// "DELETE((\\s)|(\\s[a-zA-Z]+\\s))FROM\\s([A-Z][a-z]+|[a-z]+)\\sWHERE\\s.+?\\;$"
	// };

	String white_list[] = {
			"SELECT\\s((\\*)|(DISTINCT\\s[A-ZA-Z,]+)|([\\sA-ZA-Z,()]+))\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)((\\sORDER\\sBY\\s([A-Z][A-Z]+|[A-Z]+)))?\\;$",
			"SELECT\\s((\\*)|(DISTINCT\\s[A-ZA-Z,]+)|([\\sA-ZA-Z,]+))\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)((\\sORDER\\sBY\\s([A-Z][A-Z]+|[A-Z]+)))?\\;$",
			"SELECT\\s((\\*)|(DISTINCT\\s[A-ZA-Z,]+)|([\\sA-ZA-Z,]+))\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)((\\sORDER\\sBY\\s([A-Z][A-Z]+|[A-Z]+)))?((\\sWHERE\\s[\\sA-ZA-Z,\\*\\'\\=]+))?((\\;))?$",
			"SELECT\\sCOUNT\\s\\*\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)\\;$",
			"SELECT\\s((\\*)|([\\sA-ZA-Z,]+))\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)((\\sWHERE\\s[\\sA-ZA-Z,\\*\\'\\=]+))((\\;))?$",
			"SELECT\\s([A-ZA-Z]+)\\(([A-ZA-Z]+)\\)\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)\\;$",
			"SELECT\\s((\\*)|([\\sA-ZA-Z,()]+))\\sFROM\\s([A-Z][A-Z]+|[A-Z]+)\\sWHERE\\s.+?\\;$",
			"UPDATE.+?SET\\s[A-Z]+\\s?\\=[A-Z'\\s]+((\\;$)|(\\sWHERE\\s.+?\\;$))",
			"INSERT INTO\\s([A-ZA-Z\\(\\)\\,\\s]+)\\sVALUES([A-ZA-Z\\(\\)\\,\\s\\'\\d]+)\\;$",
			"DELETE((\\s)|(\\s[A-ZA-Z]+\\s))FROM\\s([A-Z][A-Z]+|[A-Z]+)\\sWHERE\\s.+?\\;$" };

	// String black_list[] = { "[\\x22\\x27]\\s*OR\\s*\\d+\\x3d\\d+",
	// "(OR|AND)(\\s+?).+?=[\\x22\\x27](\\s+?)[\\x22\\x27]$",
	// "(OR|AND)(\\s+?).+?=(\\s+?)[\\x22\\x27]$",
	// "([\\x22\\x27])?(\\s+?)--(\\s+?)([\\x22\\x27])?",
	// ".+?=[\\x22\\x27]\\*[\\x22\\x27]\\s(AND|OR)\\s.+?=[\\x22\\x27][\\x22\\x27]",
	// "\\x3bDROP",
	// "((\\x27)|(\\x22))\\*((\\x27)|(\\x22))", "#.+?WHERE.+?SELECT",
	// "--.+?[\\x22\\x27]", "%27%20",
	// "\\/\\*|\\*\\/", ";.+?$",
	// "\\w*((\\%27)|(\\'))(\\s?)((\\%6F)|(\\%4F))((\\%72)|(\\%52))",
	// "\\w*((\\%27)|(\\'))(\\s?)((\\%6F)|o|(\\%4F))((\\%72)|r|(\\%52))",
	// "\\w*((\\%6F)|(\\%4F))((\\%72)|(\\%52))(\\s?)((\\%27)|(\\'))",
	// ".+?(\\%2A).+?$", ".+?(0x3(a|A)).+?$",
	// ".+?information_schema.+?$" };

	String black_list[] = { "[\"\']\\s*OR\\s*\\d+\\x3d\\d+", "(OR|AND)(\\s+?).+?=[\"\'](\\s+?)[\"\']$",
			"(OR|AND)(\\s+?).+?=(\\s+?)[\"\']$", "([\"\'])?(\\s+?)--(\\s+?)([\"\'])?",
			".+?=[\"\']\\*[\"\']\\s(AND|OR)\\s.+?=[\"\'][\"\']", "\\x3bDROP", "((\')|(\"))\\*((\')|(\"))",
			"#.+?WHERE.+?SELECT", "--.+?[\"\']", "\'\\s", "\\/\\*|\\*\\/", ";.+?$",
			"\\w*((\')|(\\'))(\\s?)((o)|(O))((\\r)|(\\R))", "\\w*((\')|(\\'))(\\s?)((o)|o|(O))((\r)|r|(\\R))",
			"\\w*((o)|(O))((\\r)|(\\R))(\\s?)((\')|(\\'))", ".+?(\\*).+?$", ".+?(\\?(a|A)).+?$",
			".+?information_schema.+?$" };

	public boolean isGrammarCorrect(String query) {
		if ((charCount(query, '\'') % 2 != 0) || (charCount(query, '"') % 2 != 0)) {
			return false;
		} else if (charCount(query, '(') != charCount(query, ')')) {
			return false;
		} else {
			return true;
		}
	}

	public boolean testAgainstWhiteList(String query) {
		boolean result = false;
		for (String regex : white_list) {
			// System.out.println("Query: "+query);
			// System.out.println("Regex: "+regex);
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(query);
			result = m.matches();
			if (result)
				break;
		}
		return result;
	}

	public boolean testAgainstBlackList(String query) throws UnsupportedEncodingException {
		boolean result = false;
		for (String regex : black_list) {
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(query);
			result = m.matches();
			if (result)
				break;
		}
		return result;
	}

	public int charCount(String str, char c) {
		int count = 0;
		for (char ch : str.toCharArray()) {
			if (ch == c) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) throws UnsupportedEncodingException {
		SQLiID s = new SQLiID();
		String valid_query[] = { "SELECT CustomerName,City FROM Customers;", "SELECT USN FROM student ORDER BY age;",
				"SELECT USN FROM student;", "INSERT INTO student (id, name, age) VALUES ('4', 'chris', '28');",
				"SELECT COUNT(USN) FROM student;", "SELECT id , name , MAX(age) FROM student;",
				"SELECT sum(age) FROM student;", "SELECT USN FROM student WHERE name = �dan� AND age = 24;",
				"SELECT USN FROM student WHERE name = �dan� OR age > 25;", "SELECT name FROM student WHERE age > 25;",
				"INSERT INTO Customers (CustomerName, City, Country) VALUES ('Cardinal', 'Stavanger', 'Norway');",
				"UPDATE Customers SET ContactName='Alfred Schmidt', City='Hamburg';",
				"SELECT CID FROM Customers WHERE City IN ('Paris','London');",
				"SELECT CID FROM Customers WHERE CustomerID=1;",
				"SELECT CID FROM Customers WHERE Country='Germany' AND City='Berlin';",
				"SELECT CID FROM Customers WHERE Country LIKE '%land%';",
				"UPDATE Customers SET ContactName='Alfred Schmidt', City='Hamburg' WHERE CustomerName='Alfreds Futterkiste';",
				"DELETE FROM Customers WHERE CustomerName='Alfreds Futterkiste';",
				"SELECT DISTINCT City FROM Customers;", "SELECT PID FROM Persons WHERE ROWNUM <=5;",
				"SELECT CID FROM Customers WHERE Country='Germany' AND (City='Berlin' OR City='M�nchen');",
				"SELECT CID FROM Customers WHERE City LIKE '[bsp]%';",
				"SELECT PID FROM Products WHERE ProductName BETWEEN 'C' AND 'M';",
				"SELECT City FROM Customers UNION SELECT City FROM Suppliers ORDER BY City;",
				"SELECT CID FROM Customers WHERE City='Berlin' OR City='M�nchen';" };

		for (String q : valid_query) {
			System.out.println(s.isGrammarCorrect(q.toUpperCase()) + " " + s.testAgainstWhiteList(q.toUpperCase())
					+ "  " + s.testAgainstBlackList(q.toUpperCase()));
		}

		System.out.println("\nStart malicious queries \n");

		String malicious_queries[] = { "SELECT * FROM users WHERE username='*' AND password=''",
				"SELECT * FROM users WHERE username='admin'--' AND password=''",
				"SELECT * FROM users WHERE username='admin' AND password='' OR 1=1--'",
				"SELECT * FROM users WHERE username='';SHUTDOWN --' AND password=''",
				"SELECT * FROM Users WHERE Username='1' OR '1' = '1' AND Password='1' OR '1' = '1'",
				"SELECT * FROM users WHERE username='SELECT Username FROM Users WHERE ID=1' AND password='SELECT MD5(Password) FROM Users WHERE ID=1'",
				"SELECT * FROM users WHERE username='*' AND password=''",
				"SELECT * FROM users WHERE username='admin'#' AND password=''",
				"SELECT * FROM users WHERE username='';DROP tempTable;' AND password=''",
				"SELECT * FROM users WHERE username='admin' AND password='' OR 1=1 --IamJOE'",
				"SELECT * FROM users WHERE username='admin' AND password=' ' OR ''=''",
				"SELECT * FROM users WHERE username='admin' AND password=%27%20or%20%27%27%3D%27",
				"SELECT * FROM users WHERE username='' AND password='' UNION SELECT 1, 'anotheruser', 'doesnt matter', 1-- '",
				"SELECT * FROM users WHERE username='' AND users NOT IN ('First User', 'Second User');--' AND password=''",
				"SELECT * FROM users WHERE username='admin';DROP myTable--' AND password=''",
				"SELECT * FROM users WHERE username='/*!32302 1/0, */' AND password='' ",
				"SELECT * FROM users WHERE username='' AND password='';IF((SELECT user) = 'sa' OR (SELECT user) = 'dbo') SELECT 1 ELSE SELECT 1/0;--'",
				"SELECT * FROM users WHERE username='';waitfor delay '0:0:10'--' AND password=''",
				"SELECT * FROM users WHERE username='CAST('username' AS SIGNED INTEGER)' AND password=''",
				"SELECT * FROM users WHERE username='' UNION SELECT SUM(columntofind) FROM users--' AND password=''",
				"SELECT * FROM users WHERE username='' AND password='' ORDER BY 1;--'",
				"SELECT * FROM users WHERE username='' + (SELECT TOP 1 username FROM users ) + '' AND password='' + (SELECT TOP 1 password FROM users ) + ''",
				"SELECT * FROM users WHERE username='';SELECT name FROM syscolumns WHERE id =(SELECT id FROM sysobjects WHERE name = 'known_table_name');--' AND password=''",
				"SELECT table_name FROM information_schema.columns WHERE column_name = 'username';",
				"SELECT table_name FROM information_schema.columns WHERE column_name LIKE '%user%';",
				"SELECT column_name FROM information_schema.columns WHERE table_name = 'Users';",
				"SELECT column_name FROM information_schema.columns WHERE table_name LIKE '%user%';?" };
		for (String q : malicious_queries) {
			System.out.println(s.isGrammarCorrect(q.toUpperCase()) + " " + s.testAgainstWhiteList(q.toUpperCase())
					+ "  " + s.testAgainstBlackList(q.toUpperCase()));

		}

	}

}
