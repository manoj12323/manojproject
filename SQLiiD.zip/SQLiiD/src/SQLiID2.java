import java.util.regex.Matcher;
import java.util.regex.Pattern;

// As per symantec web site
public class SQLiID2 {

	public static void main(String[] args) {

		// Regex for detecting SQL meta characters;
		String regex = "/\\w*((\\%27)|(\\'))((\\%6F)|o|(\\%4F))((\\%72)|r|(\\%52))/ix";	
		String query = "SELECT * FROM users WHERE username='admin';DROP myTable--' AND password=''";
		
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(query);
		boolean result = m.matches();
		
		System.out.println(result);


	}

}
